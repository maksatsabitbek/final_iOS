//
//  UpdateProductService.swift
//  myShopFinal
//  Created by Мас on 11.06.2021.

import Foundation
import Firebase
import FirebaseStorage

class UpdateProductService: ObservableObject {
    private let db = Firestore.firestore()
    
    @Published var postmodel: [PostModel] = []
    private let collectionName = "posts"
    
   
    func upDateProduct(id: String){
        db.collection(collectionName).document(id).updateData([
            "name": "Done"
        ]) { error in
            print(error ?? "Update failed.")
        }

    }
    
   
}

