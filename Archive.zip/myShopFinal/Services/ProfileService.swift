//
//  ProfileService.swift
//  myShopFinal
//  Created by Мас on 11.06.2021.

import Foundation
import Firebase
import SwiftUI

//ใช้ในการ load post เฉพาะของ user ใน session ที่ login อยู่
class ProfileService: ObservableObject {
    
    @Published var posts: [PostModel] = []
    
    func loadUserPosts(userId: String) {
        PostService.loadUserPosts(userId: userId) {
            (posts) in
            
            self.posts = posts
        }
    }
}
