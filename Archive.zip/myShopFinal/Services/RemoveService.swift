//
//  RemoveService.swift
//  myShopFinal
//  Created by Мас on 11.06.2021.

import Foundation
import Firebase
import FirebaseStorage

class RemoveService: ObservableObject {
    private let db = Firestore.firestore()
    
    @Published var post: [PostModel] = []
    private let collectionName = "posts"
    
   
    func remove(post : PostModel) {
            db.collection(collectionName).document(post.postID).delete()
            { err in
                if let err = err {
                  print("Error removing document: \(err)")
                }
                else {
                  print("Document successfully removed!")
                }
            }
        }
   
}
