//
//  PostCardService.swift
//  myShopFinal
//  Created by Мас on 11.06.2021.

import Foundation
import Firebase
import SwiftUI

class PostCardService : ObservableObject {
    @Published var post: PostModel!
    
}
