//
//  PostModel.swift
//  Created by Мас on 11.06.2021.

import Foundation
struct PostModel: Encodable, Decodable {
    var caption: String
    var ownerID: String
    var postID: String
    var username : String
    var profile: String
    var mediaUrl: String
    var category: String
    var allPost : String
}
